## After the hands-on lab

Duration: 10 minutes

### Task 1: Clean up resources

You should complete all of these steps _after_ attending the Hands-on lab. Failure to delete the resources created during the lab will result in continued billing.

1. Delete the **SmartHotelHostRG** resource group containing the SmartHotelHost.

2. Delete the **BastionRG** resource group containing the Azure Bastion.

3. Delete the **SmartHotelRG** resource group containing the migrated VMs and related infrastructure resources.

4. Delete the **AzureMigrateRG** resource group containing the Azure Migrate resources (if not done already at the end of Exercise 3).

You should follow all steps provided _after_ attending the Hands-on lab.