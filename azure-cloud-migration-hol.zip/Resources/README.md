# NOTES

Several PowerShell scripts are used to bootstrap the Host VM. They download and deploy the nested Hyper-V VMs that constitute the 'on-premises' environment.

These scripts are copied from the GitHub repo to the cloudworkshop storage account (to the 'line-of-business-application-migration' container), and used from there.
